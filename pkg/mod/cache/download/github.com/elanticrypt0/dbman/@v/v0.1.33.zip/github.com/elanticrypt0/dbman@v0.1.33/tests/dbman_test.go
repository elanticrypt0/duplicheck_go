package tests

import (
	"testing"
)

func TestDBManLoadConfigFromEnv(t *testing.T) {

}

func TestDBManLoadConfigFromToml(t *testing.T) {

}

func TestDBManConnect2Postgres(t *testing.T) {

}

func TestDBManConnect2Mysql(t *testing.T) {

}

func TestDBManConnect2SQLite(t *testing.T) {

}

func TestDBManSetPrimary(t *testing.T) {

}

func TestDBManSetSecondary(t *testing.T) {

}

func TestDBManSetSecurity(t *testing.T) {

}

func TestDBManGetInstance(t *testing.T) {

}
